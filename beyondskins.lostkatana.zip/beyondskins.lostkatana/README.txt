===============================================
Raider of the lost katana
===============================================

.. contents:: Table of Contents
   :depth: 2

Overview
--------

Raiders of lost katana is a Plone Theme developed by `Simples
Consultoria <http://www.simplesconsultoria.com.br/>`_ using Diazo.

You could use this theme in your project or as a start for you own Diazo themes -- but send us a
postcard, ok ;-)

Requirements
------------

    * Plone 4.2.x (http://plone.org/products/plone)
    

Screenshots
------------

Layout of the site when viewed in a computer resolution:

.. image:: https://github.com/simplesconsultoria/beyondskins.lostkatana/raw/master/preview.jpg


Installation
------------

Getting the theme
~~~~~~~~~~~~~~~~~~~~

    1. Download a `zip file <https://github.com/simplesconsultoria/beyondskins.lostkatana/archive/master.zip>`_ 
        
    2. Import the theme from the Diazo theme control panel.


Credits
-------
      
    * Andre Nogueira (andre at simplesconsultoria dot com dot br) - Conception 
      and prototype.


